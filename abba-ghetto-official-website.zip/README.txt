ABBA GHETTO OFFICIAL WEBSITE
==============================

Files:
- index.html
- assets/hero.jpg

The site is a responsive one-page official profile for Abdulsalam Abdullahi Koli / Abba Ghetto (Yaro Gulamu).

Next publishing step:
1. Choose a domain name.
2. Upload index.html and the assets folder to a web host.
3. Connect Google Search Console after the site is live.
